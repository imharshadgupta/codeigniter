<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="<?php echo base_url();?>download_or_export_csv/export_xml" method="post">
<input type="submit" value="download xml"> 
</form>
<form action="<?php echo base_url();?>download_or_export_csv/export_csv" method="post">
<input type="submit" value="download csv">
</form>
</body>
</html>