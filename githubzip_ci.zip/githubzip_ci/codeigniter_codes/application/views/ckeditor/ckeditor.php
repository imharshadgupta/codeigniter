<!DOCTYPE html>
<html>
<head>
<script type="text/javascript" src="<?php echo site_url('assets/ckeditor/ckeditor.js'); ?>"></script>
<script type="text/javascript" src="<?php echo site_url('assets/ckfinder/ckfinder.js'); ?>"></script>
	<title></title>
</head>
<body>


  <form action="<?php echo base_url();?>Ckeditor_controller/add_data_by_ckeditor?>" method="post">
            <textarea name="editor1" id="editor1" rows="10" cols="80">
                This is my textarea to be replaced with CKEditor.
            </textarea>
            <input type="submit" name="">


    <script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    // CKEDITOR.replace( 'editor1' );

    var editor = CKEDITOR.replace( 'editor1', {
    filebrowserBrowseUrl : 'ckfinder/ckfinder.html',
    filebrowserImageBrowseUrl : './assets/ckfinder/ckfinder.html?type=Images',
    filebrowserFlashBrowseUrl : './assets/ckfinder/ckfinder.html?type=Flash',
    filebrowserUploadUrl : './assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
    filebrowserImageUploadUrl : './assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
    filebrowserFlashUploadUrl : './assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
});
    CKFinder.setupCKEditor( editor, '/ckfinder/' );
    </script>

        </form>
</body>
</html>