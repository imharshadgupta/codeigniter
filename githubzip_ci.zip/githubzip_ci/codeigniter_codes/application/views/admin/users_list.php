<div class="container">
    <div class="grids">
        <div class="progressbar-heading grids-heading">
            <h2>All users</h2>
        </div>

        <table class="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>edit</th>
                <th>edit</th>
                
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>edit</th>
                <th>edit</th>
                
            </tr>
        </tfoot>
        <tbody>
        <?php foreach ($all_user as $key => $all_users) {
                echo '<tr><td>'.$all_users['name'].'</td>';
               echo'<td>'.$all_users['name'].'</td>';
                echo'<td>'.$all_users['name'].'</td>';
                 echo'<td>'.$all_users['name'].'</td>';
                 echo'<td><button id="myBtn" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">Launch demo modal</button></td></tr>';
                 echo'<td><a href="#" onclick="openModal()">Open a Modal by jQuery</a></td></tr>';
                
        } ?>
           
               
          
             
            </tbody>
    </table>

   <!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                 <h4 class="modal-title" id="myModalLabel">Modal title</h4>

            </div>
            <div class="modal-body">...</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>


<script type="text/javascript">
    $(document).ready(function () {

     // Attach Button click event listener 
    $("#myBtn").click(function(){
        alert();
         // show Modal
         $('#myModal').modal('show');
    });
});
</script>
<script type="text/javascript">

function openModal(){

    $('#myModal').modal();
}       
</script>
</div>
</div>
