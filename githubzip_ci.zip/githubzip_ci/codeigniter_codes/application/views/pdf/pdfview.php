<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="<?php echo base_url();?>Pdf_controller/pdf" method="post">
<input type="submit" value="download pdf"> 
</form>
</body>
</html>