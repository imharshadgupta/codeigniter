<div class="col-lg-4 col-lg-offset-4">
    <h2>Reset your password</h2>
    <h5>Please enter your password 2x below to reset</h5>     
<?php 
    $fattr = array('class' => 'form-signin');
    echo form_open(site_url().'users/ForgotPassword_emailclick/', $fattr); ?>
    <div class="form-group">
      <?php echo form_password(array('name'=>'password', 'id'=> 'password', 'placeholder'=>'Password', 'class'=>'form-control', 'value' => set_value('password'))); ?>
      <?php echo form_error('password') ?>
    </div>
    <div class="form-group">
      <?php echo form_password(array('name'=>'confirm_pass', 'id'=> 'confirm_pass', 'placeholder'=>'Confirm Password', 'class'=>'form-control', 'value'=> set_value('confirm_pass'))); ?>
      <?php echo form_error('confirm_pass') ?>
    </div>
    <?php //echo form_hidden('user_id', $user_id);?>
    <?php echo form_submit(array('value'=>'Reset Password')); ?>
    <?php echo form_close(); ?>
   
</div>