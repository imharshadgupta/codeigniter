<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends CI_Model{
    function __construct() {
        $this->userTbl = 'users';
    }
    /*
     * get rows from the users table
     */
    function getRows($params = array()){
        $this->db->select('*');
        $this->db->from($this->userTbl);
        
        //fetch data by conditions
        if(array_key_exists("conditions",$params)){
			foreach ($params['conditions'] as $key => $value) {
				$this->db->where($key,$value);
			}
		}
        
        if(array_key_exists("id",$params)){
            $this->db->where('id',$params['id']);
			$query = $this->db->get();
			$result = $query->row_array();
        }else{
            //set start and limit
            if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit'],$params['start']);
            }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
                $this->db->limit($params['limit']);
            }
            $query = $this->db->get();
            if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
				$result = $query->num_rows();
			}elseif(array_key_exists("returnType",$params) && $params['returnType'] == 'single'){
				$result = ($query->num_rows() > 0)?$query->row_array():FALSE;
			}else{
                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            }
        }

        //return fetched data
        return $result;
    }

    public function email_check_exists($key){

    $this->db->where('email',$key);
    $query = $this->db->get('users');
    // $query->num_rows();
    if ($query->num_rows() > 0){
        return false;
    }
    else{
        return true;
    }

    }
    
	/*
	 * Insert user information
	 */
    public function insert($data = array(),$id=0) {
        // echo 11;die;
        //add created and modified data if not included
        if(!array_key_exists("created", $data)){
            $data['created'] = date("Y-m-d H:i:s");
        }
        if(!array_key_exists("modified", $data)){
            $data['modified'] = date("Y-m-d H:i:s");
        }
        
        if ($id == 0) {
            // echo 5;die;
        //insert user data to users table
        $insert = $this->db->insert($this->userTbl, $data);
        
        //return the status
        if($insert){
            return $this->db->insert_id();;
        }else{
            return false;
        }
    }else{
        $this->db->where('id', $id);
        return $this->db->update($this->userTbl, $data);
    }
    }

    public function edit_users($id){

           
           
        
 
        $query = $this->db->get_where($this->userTbl, array('id' => $id));
        return $query->row_array();
    }

    public function get_all_users(){
         $query = $this->db->get($this->userTbl);
            return $query->result_array();
    }


    public function ForgotPassword($email)
 {
        $this->db->select('email');
        $this->db->from('users'); 
        $this->db->where('email', $email); 
        $query=$this->db->get();
        return $query->row_array();
 }
 public function insertToken($email,$token){
        $this->db->where('email', $email);
        $data = array('token' => $token );
        $this->db->update('users', $data); 
        return true;
 }
 public function isTokenValid($email='',$Token=''){

        $this->db->from('users'); 
        $this->db->where('email', $email); 
        $this->db->where('Token', $Token); 
        $query=$this->db->get();
        return $query->row_array();
        print_r($a);die;
 }

    

public function save()
 {
  $pass = md5($this->input->post('new'));
  $data = array (
   'password' => $pass
   );
  $this->db->where('id', $this->session->userdata('userId'));
  $this->db->update('users', $data);
 }

 public function cek_old()
  {
   $old = md5($this->input->post('old'));
   $this->db->where('password',$old);
   $query = $this->db->get('users');
      return $query->result();;
    }

    public function updatePassword($data_password='',$id='',$token=''){
        echo $data_password;
        echo $id;
        echo $token;die;
        $this->db->where('id', $id);
        $this->db->where('token', $token);
        return $this->db->update($this->userTbl, $data_password);
    }
}
