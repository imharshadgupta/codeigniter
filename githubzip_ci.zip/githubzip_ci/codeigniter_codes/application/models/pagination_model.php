<?php class Pagination_model extends CI_Model
{
    public function __construct() {
        parent::__construct();
    }

    public function record_count() {
        // Count all record of table
        return $this->db->count_all("users");

        // $result = $this->db->query("select count(*) as c from posts");
        // $row = $result->row_array();
    }

    public function fetch_users($limit, $start) {
        // Fetch data according to per_page limit.
         $this->db->order_by('id','desc');
        $this->db->limit($limit, $start);
        $query = $this->db->get("users");

        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
   }
}