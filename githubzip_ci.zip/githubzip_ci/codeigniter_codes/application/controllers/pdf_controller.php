<?php
class Pdf_controller extends CI_Controller {

public function index(){
    $this->load->view('pdf/pdfview');
}

public function pdf(){
	$this->load->library('pdf');
// $this->pdf->load_view('welcome');
	$dompdf = new DOMPDF();
// $this->dompdf->render();
// $this->dompdf->stream("pdf.pdf");


 $html = $this->load->view('pdf/pdf',null, true);
 // print_r($html);die;
                    
                    $dompdf->load_html($html);

                    $this->dompdf->set_paper("A4", "portrait"); // to change page orientation to landscape, change the parameter “portrait” to “landscape”
                    $dompdf->render();

                    $pdf = $dompdf->output();

                // ===============================================
                // for pagination 
                $canvas = $this->dompdf->get_canvas();
               // $a=trim($invData['DataInvoice']['invoice_number']);
                $font = Font_Metrics::get_font("helvetica", "bold");
               // $canvas->page_text(263, 822, "".$a." Page {PAGE_NUM} of {PAGE_COUNT}",$font, 10, array(0,0,0));
                // $canvas->page_text(72, 18, "Header: {PAGE_NUM} of {PAGE_COUNT}",
                //    $font, 6, array(0,0,0));
                // ===============================================

                    $filename = "test.pdf";
                  // echo  $path = realpath(dirname(dirname(dirname(dirname(dirname(__FILE__)))))).'/assets/pdf/';die;
                 $path = $_SERVER['DOCUMENT_ROOT'].'/codeigniter_codes/assets/pdf/';
                    if(file_exists($path.$filename)) {
                        unlink($path.$filename);
                    }
                    //$filename = 'sdhgkdfg'."-".$inst_pkg.".pdf";
                    file_put_contents($path.$filename, $pdf);
                    $this->downloadPdf();
}

public function downloadPdf(){
			$this->load->helper('download');
            // $path = realpath(dirname(dirname(dirname(dirname(dirname(__FILE__)))))).'/assets/pdf/test.pdf';
			$path = $_SERVER['DOCUMENT_ROOT'].'/codeigniter_codes/assets/pdf/test.pdf';
			// $data = file_get_contents('E:/xampp/htdocs/radius_manger/assets/images/uploads/1.pdf'); 
			$data = file_get_contents($path); 
			// $name = '1.pdf'; 
			$name = 'test.pdf'; 
			force_download($name,$data);
	}
} 
 ?>