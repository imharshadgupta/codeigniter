<?php 
class Email_controller extends CI_Controller {
// https://stackoverflow.com/questions/21836282/php-function-mail-isnt-working

	// https://www.codexworld.com/codeigniter-send-email-gmail-smtp-server/

	// http://only4ututorials.blogspot.in/2015/07/send-email-with-attachment-codeigniter.html
	public function testemail(){

		// ini_set('SMTP', "localhost");
// ini_set('smtp_port', "25");
// ini_set('sendmail_from', "your@example.com");

		$config = Array(
//     'protocol' => 'smtp',
//     'smtp_host' => 'ssl://smtp.googlemail.com',
//     'smtp_port' => 465,
//     'smtp_user' => 'xxx',
//     'smtp_pass' => 'xxx',
    'mailtype'  => 'html', 
//     'charset'   => 'iso-8859-1'
		  // 'wordwrap' => TRUE
);
		// $this->email->initialize($config);
$this->load->library('email', $config);
// $this->email->set_newline("\r\n");

// 		ou need to enable SSL in your PHP config. Load up php.ini and find a line with the following:

// ;extension=php_openssl.dll

		$this->load->library('session');
		// $this->load->library('email');

		$htmlContent = '<h1>Sending email via SMTP server</h1>';
$htmlContent .= '<p>This email has sent via SMTP server from CodeIgniter application.</p>';

		$from_email = "your@example.com"; 
        // $to_email = $this->input->post('email'); 
        $to_email = "imharshadgupta01@gmail.com" ;

  // $path=$_SERVER["DOCUMENT_ROOT"];
    // $file=$path."/ci/attachments/info.txt";
		$this->email->from($from_email, 'Your Name');
$this->email->to($to_email);
 
$this->email->subject('Email Test');
$this->email->message($htmlContent);

// $attched_file= $_SERVER["DOCUMENT_ROOT"];
// C:\Users\HARSHAD\Downloads\IMG_20151228_185645-1.jpeg;
$this->load->helper('path');
		 $path = set_realpath('assets');
		 // echo $path . 'IMG_20151228_185645-1.jpeg';die;
		 $this->email->attach($path . '2.jpg');
		 $this->email->attach($path . 'ad.csv');
// $this->email->attach('/path/to/file1.png'); // attach file
    // $this->email->attach('/path/to/file2.pdf');

// $this->email->cc('another@another-example.com');
// $this->email->bcc('them@their-example.com');

 if($this->email->send()) {
         echo "email_sent","Email sent successfully."; 

     }else {
         $this->session->set_flashdata("email_sent","Error in sending Email.");
     }
      // $this->load->view('email_form');
     }


	// $from_email = "your@example.com"; 
        // $to_email = $this->input->post('email'); 
        // $to_email = "imharshadgupta01@gmail.com" ;
     public function send_mail1() {
     	$this->load->library('My_PHPMailer');
        $mail = new My_PHPMailer();
        $mail->IsSMTP(); // we are going to use SMTP
        $mail->SMTPAuth   = true; // enabled SMTP authentication
        $mail->SMTPSecure = "ssl";  // prefix for secure protocol to connect to the server
        $mail->Host       = "smtp.gmail.com";      // setting GMail as our SMTP server
        $mail->Port       = 587;                   // SMTP port to connect to GMail
        $mail->Username   = "imharshadgupta01@gmail.com";  // user email address
        $mail->Password   = "hanumannjai";            // password in GMail
        $mail->SetFrom('your@example.com', 'Firstname Lastname');  //Who is sending the email
        $mail->AddReplyTo("imharshadgupta01@gmail.com","Firstname Lastname");  //email address that receives the response
        $mail->Subject    = "Email subject";
        $mail->Body      = "HTML message
";
        $mail->AltBody    = "Plain text message";
        $destino = "imharshadgupta01@gmail.com"; // Who is addressed the email to
        $mail->AddAddress($destino, "John Doe");

        // $mail->AddAttachment("images/phpmailer.gif");      // some attached files
        // $mail->AddAttachment("images/phpmailer_mini.gif"); // as many as you want
        if(!$mail->Send()) {
            echo "Error: " . $mail->ErrorInfo;
        } else {
            echo "Message sent correctly!";
        }
        // $this->load->view('sent_mail',$data);
    }
// $this->email->send();
	
}

 ?>