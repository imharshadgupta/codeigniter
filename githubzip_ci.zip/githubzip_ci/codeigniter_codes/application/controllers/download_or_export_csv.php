<?php
class Download_or_export_csv extends CI_Controller
{

    function Generate()
    {
        parent::__construct();
        $this->load->database();
        $this->load->helper('url');
    
        /* no model required */
    }
    public function index(){
        $this->load->view('export_csv_excel_view/export_csv_excel_view');
    }
    public function export_xml()
    {
        /*xml export code*/

    $this->load->dbutil(); // call db utility library
    $this->load->helper('download'); // call download helper

    $query = $this->db->query("SELECT * FROM users LIMIT 500"); // whatever you want to export to CSV, just select in query

            $config = array (
                'root'          => 'root',
                'element'       => 'element',
                'newline'       => "\n",
                'tab'           => "\t"
            ); // define XML document structure

    $filename = 'dumpexport.xml'; // name of csv file to download with data
    force_download($filename, $this->dbutil->xml_from_result($query, $config)); // download file

    }

    public function export_csv()
    {
    
    /* csv export code */
    $delimiter = "|";  // pipe delimited 
    $newline = "\r\n";
    $enclosure = '"';

    $this->load->dbutil(); // call db utility library
    $this->load->helper('download'); // call download helper

    $query = $this->db->query("SELECT * FROM users LIMIT 500"); // whatever you want to export to CSV, just select in query
    
    $filename = 'dumpexport.csv'; // name of csv file to download with data
    force_download($filename, $this->dbutil->csv_from_result($query)); // download file
    // force_download($filename, $this->dbutil->csv_from_result($query, $delimiter, $newline)); 
         
    }


     
}