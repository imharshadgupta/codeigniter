<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Users extends My_Controller {
    
    function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('user');
        $this->load->helper('my_helper');
        $this->load->helper('url');
    }
    
    /*
     * User account information
     */
    public function index()
    {
        redirect( base_url().'users/login', 'refresh');
    }
    public function account(){
        $data = array();
        if($this->session->userdata('isUserLoggedIn')){
        // is_login();
            $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
            //load the view
            if($data['user']['user_type']=='1'){
         $data['all_user'] = $this->user->get_all_users();
         // echo '<pre>';print_r($data);die;
               $this->load->view('common_files/header');
                 $this->load->view('admin/users_list', $data);
                $this->load->view('common_files/footer');
            }else{
                    $this->load->view('common_files/header');
                  $this->load->view('users/account', $data);
        $this->load->view('common_files/footer');
            }
  
           
        }else{
            redirect('users/login');
        }
    }
    
    /*
     * User login
     */
    public function login(){
      // $this->testing();die;
  
        $data = array();
        if($this->session->userdata('success_msg')){
            $data['success_msg'] = $this->session->userdata('success_msg');
            $this->session->unset_userdata('success_msg');
        }
        if($this->session->userdata('error_msg')){
            $data['error_msg'] = $this->session->userdata('error_msg');
            $this->session->unset_userdata('error_msg');
        }
        if($this->input->post('loginSubmit')){
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('password', 'password', 'required');
            if ($this->form_validation->run() == true) {
                $con['returnType'] = 'single';
                $con['conditions'] = array(
                    'email'=>$this->input->post('email'),
                    'password' => md5($this->input->post('password')),
                    'status' => '1'
                );
                $checkLogin = $this->user->getRows($con);
                if($checkLogin){
                    $this->session->set_userdata('isUserLoggedIn',TRUE);
                    $this->session->set_userdata('userId',$checkLogin['id']);
                    redirect('users/account/');
                }else{
                      $data['error_msg'] =$this->session->set_flashdata('error_msg','login credential wrong');
                }
            }
        }
        //load the view
          $this->load->view('common_files/header');
        $this->load->view('users/login', $data);
        $this->load->view('common_files/footer');
        
    }

    public function change_password(){
        $this->load->view('common_files/header');
        $this->load->view('users/change_password');
        $this->load->view('common_files/footer'); 
    }

    public function update_password()
 { 
     // if($this->session->userdata('isUserLoggedIn')){ 
        // is_login();
            // $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
  $this->form_validation->set_rules('new','New','required|alpha_numeric');
  $this->form_validation->set_rules('re_new', 'Retype New', 'required|matches[new]');
    if($this->form_validation->run() == FALSE)
  {
      $this->load->view('common_files/header');
   $this->load->view('users/change_password');
         $this->load->view('common_files/footer');
  }else{
   $cek_old = $this->user->cek_old();
   if ($cek_old == False){
    $this->session->set_flashdata('error','Old password not match!' );
   $this->load->view('common_files/header');
   $this->load->view('users/change_password');
         $this->load->view('common_files/footer');
   }else{
    $this->user->save();
    $this->session->sess_destroy();
    $this->session->set_flashdata('error','Your password success to change, please relogin !' );
         $data['user'] = $this->user->getRows(array('id'=>$this->session->userdata('userId')));
      $this->load->view('common_files/header');
   $this->load->view('users/account',$data);
         $this->load->view('common_files/footer');
   }//end if valid_user
  }
 }
    // }
    /* User registration */

    public function registration(){

        $data = array();
        $userData = array();
        if($this->input->post('registration_submit')){
             // echo 444;die;
            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check');
            $this->form_validation->set_rules('password', 'password', 'required');
            $this->form_validation->set_rules('conf_password', 'confirm password', 'required|matches[password]');

        //     $this->form_validation->set_rules('number', 'Phone Number', 'required|numeric|max_length[15]');
        // $this->form_validation->set_rules('subject', 'Subject', 'required|max_length[10]|alpha');
        // $this->form_validation->set_rules('message', 'Message', 'required|min_length[12]|max_length[100]');
 

            if($this->form_validation->run() == 1){
// echo 22;die;
                // echo '<pre>';print_r($_FILES);die;
                // $img_name = basename(multiple_upload($_FILES,'','/assets/images/upload')); 
                if(isset($_FILES) && (!empty($_FILES['userFiles']['name'][0]))){
                    // echo 2222222;die;
                $img_name = multiple_upload($_FILES,'','./assets/images/upload'); 
                }else{
                    $img_name='';
                }
            
if($this->input->post('hobbies')){
                    $arr= $this->input->post('hobbies');
                $hobbies=implode(',',$arr);
                }else{
                    $hobbies='';
                }
               
// print_r($img_name);die;
                 $userData = array(
                'name' => strip_tags($this->input->post('name')),
                'email' => strip_tags($this->input->post('email')),
                'password' => md5($this->input->post('password')),
                'gender' => $this->input->post('gender'),
                'phone' => strip_tags($this->input->post('phone')),
                'image' => $img_name,
                'hobbies' => $hobbies
            );  
// echo 222;die;
                $insert = $this->user->insert($userData);
                if($insert){
                    $this->session->set_userdata('success_msg', 'Your registration was successfully. Please login to your account.');
                    redirect('users/login');
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }
        $data['user'] = $userData;

        //load the view
        $this->load->view('common_files/header');
        $this->load->view('users/registration', $data);
        $this->load->view('common_files/footer');
    }

    public function edit_users(){
    

// echo 55;die;
     $data = array();
    $userData = array();
    $id=$this->uri->segment('3');
        if($this->input->post('edit_submit')){
            // $this->form_validation->set_rules('name', 'Name', 'required');
            // $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check');
            // $this->form_validation->set_rules('password', 'password', 'required');
            // $this->form_validation->set_rules('conf_password', 'confirm password', 'required|matches[password]');


           

            // if($this->form_validation->run() == true){

                // echo '<pre>';print_r($_FILES);
                // echo '<pre>';print_r($_POST);die;
                // $img_name = basename(common_file_upload($_FILES,'','/assets/images/upload')); 

                 $userData = array(
                'name' => strip_tags($this->input->post('name')),
                'email' => strip_tags($this->input->post('email')),
                // 'password' => md5($this->input->post('password')),
                'gender' => $this->input->post('gender'),
                'phone' => strip_tags($this->input->post('phone')),
                // 'image' => $img_name
            );  
// echo $id;die;
                $update = $this->user->insert($userData,$id);
                // print_r($update);die;
                if($update){
                    $this->session->set_userdata('success_msg', 'Your profile was updatedsuccessfully.');
                    // redirect('users/login');
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            // }
        }
        $id=$this->uri->segment('3');
     $data['user'] = $this->user->edit_users($id);
        // $data['user'] = $userData;

     // echo '<pre>';print_r($data);die;
            //load the view
    $this->load->view('common_files/header');
    $this->load->view('users/edit_users', $data);
        $this->load->view('common_files/footer');
    }
    
    /*
     * User logout
     */
    public function logout(){
        $this->session->unset_userdata('isUserLoggedIn');
        $this->session->unset_userdata('userId');
        $this->session->sess_destroy();
        redirect('users/login/');
    }
    
    /*
     * Existing email check during validation
     */
    public function email_check($key){
        $status=$this->user->email_check_exists($key);
        if($status==false){
            // echo 222;die;
             $this->form_validation->set_message('email_check', 'The given email already exists.');
        return FALSE;
        }else{
            // echo 333;die;
        return TRUE;
        }
        // $con['returnType'] = 'count';
        // $con['conditions'] = array('email'=>$str);
        // $checkEmail = $this->user->getRows($con);
        // if($checkEmail > 0){
        //     $this->form_validation->set_message('email_check', 'The given email already exists.');
        //     return FALSE;
        // } else {
        //     return TRUE;
        // }

    }

    public function forgot_password_view(){
           $this->load->view('common_files/header');
     $this->load->view('users/forgot_password_view');
        $this->load->view('common_files/footer');
    }

    public function ForgotPassword(){
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if($this->form_validation->run() == FALSE) {
                        $this->load->view('common_files/header');
                        $this->load->view('users/forgot_password_view');
                        $this->load->view('common_files/footer');
            }else{

        $email = $this->input->post('email');      
         $findemail = $this->user->ForgotPassword($email); 
         // print_r($findemail);die; 
         if($findemail['email']){
          // $this->user->sendpassword($findemail); 

          // $passwordplain  = rand(0,9999999999);
          $passwordplain  = mt_rand(1000000000, mt_getrandmax());

        $passwordplain = md5($passwordplain);

        $token = $this->user->insertToken($findemail['email'],$passwordplain);                    
        $qstring = urlencode($passwordplain);   
        $qstring1 = urlencode($findemail['email']);   


         $url = base_url() . 'users/reset_password_by_user?email='.$qstring1.'&token=' . $qstring;
                $link = '<a href="' . $url . '">' . $url . '</a>'; 
                
                $message = '';                     
                $message .= '<strong>A password reset has been requested for this email account</strong><br>';
                $message .= '<strong>Please click:</strong> ' . $link;

                $config = Array(
//     'protocol' => 'smtp',
//     'smtp_host' => 'ssl://smtp.googlemail.com',
//     'smtp_port' => 465,
//     'smtp_user' => 'xxx',
//     'smtp_pass' => 'xxx',
    'mailtype'  => 'html', 
//     'charset'   => 'iso-8859-1'
          // 'wordwrap' => TRUE
);
        // $this->email->initialize($config);
$this->load->library('email', $config);
// $this->email->set_newline("\r\n");

//      ou need to enable SSL in your PHP config. Load up php.ini and find a line with the following:

// ;extension=php_openssl.dll

        $this->load->library('session');

        $from_email = "your@example.com"; 
        // $to_email = $this->input->post('email'); 
        $to_email = "imharshadgupta01@gmail.com" ;

  // $path=$_SERVER["DOCUMENT_ROOT"];
    // $file=$path."/ci/attachments/info.txt";
        $this->email->from($from_email, 'Your Name');
$this->email->to($to_email);
 
$this->email->subject('Email Test');
$this->email->message($message); 

if($this->email->send()) {
         echo "email_sent","Email sent successfully."; 

     }else {
         $this->session->set_flashdata("email_sent","Error in sending Email.");
     }            
                       

           }else{
          $this->session->set_flashdata('msg',' Email not found!');
          redirect(base_url().'user/Login','refresh');
    }
            }
       
}

public function reset_password_by_user(){
            $this->load->view('common_files/header');
                        $this->load->view('users/forgot_password_by_user');
                        $this->load->view('common_files/footer');
}


public function ForgotPassword_emailclick()
        {
              $email=urldecode($this->input->get('email'));   
              $token=$this->input->get('token');   
            echo $email;
            echo $token;die;
            // $token = $this->uri->segment(4);         
            // $cleanToken = $this->security->xss_clean($token);
            // $email=urldecode($this->uri->segment(3));
            // echo $email;die;
            $user_info = $this->user->isTokenValid($email,$token); //either false or array();               
          print_r($user_info);  die;
            if($user_info){
                $data_password=array(
                     'password' => md5($this->input->post('password')),               
                     
                    );  
               $id= $user_info['id'];
                $w=$this->user->updatePassword($data_password,$id,$token);
              //  echo $email;
                echo $w;die;
                $this->session->set_flashdata('flash_message', 'Token is invalid or expired');
                redirect(site_url().'users/login');
            }            
            // $data = array(
            //     'firstName'=> $user_info['name'], 
            //     'email'=>$user_info['email'],                
            //     'user_id'=>$user_info['id'],                
            //     'token'=>$token
            // );
            // print_r($data);  die;
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[2]');
            $this->form_validation->set_rules('confirm_pass', 'Password Confirmation', 'required|matches[password]');              
            
            if ($this->form_validation->run() == FALSE) {   
                  // echo 22222;die;  
              $this->load->view('common_files/header');
                        $this->load->view('users/forgot_password_by_user',$data);
                        $this->load->view('common_files/footer');
            }else{
                       // echo 22;die;         
                // $this->load->library('password');                 
                // $post = $this->input->post(NULL, TRUE); 
                $data_password=array(
                     'password' => md5($this->input->post('password')),               
                     
                    );               
                 $id=$this->input->post('user_id');      
                // $cleanPost = $this->security->xss_clean($post);                
                // $hashed = $this->password->create_hash($cleanPost['password']);                
                // $cleanPost['password'] = $hashed;
                // $cleanPost['user_id'] = $user_info['id'];
                // unset($cleanPost['passconf']);  
                  print_r($user_info);  die;
                              // echo 'hello';die;
                if(!$this->user->updatePassword($cleanPost)){
                    $this->session->set_flashdata('flash_message', 'There was a problem updating your password');
                }else{
                    $this->session->set_flashdata('flash_message', 'Your password has been updated. You may now login');
                }
                redirect(site_url().'main/login');                
            }
        }
}



    // $query = $this->db->get();
    // $query->row();

    // return $query->num_rows();


    // https://www.formget.com/form-login-codeigniter/
    // http://www.w3programmers.com/build-a-full-featured-login-and-registration-system-with-codeigniter/
    // https://github.com/hedii/Codeigniter-login-logout-register/blob/master/application/controllers/User.php
    // https://www.codexworld.com/downloads/codeigniter-user-registration-login-system/
    // http://itsolutionstuff.com/post/codeigniter-3-crudcreate-read-update-and-delete-using-jquery-ajax-bootstrap-models-and-mysqlexample.html
    // https://blog.allshorevirtualstaffing.com/how-to-develop-basic-crud-operations-in-codeigniter
    // http://www.w3programmers.com/introduction-to-codeigniter-basic-with-crud/
    // http://www.discussdesk.com/simple-mysql-crud-operation-in-codeigniter-with-example.htm
    // http://blog.chapagain.com.np/codeigniter-simple-mvc-crud-add-edit-delete-view/