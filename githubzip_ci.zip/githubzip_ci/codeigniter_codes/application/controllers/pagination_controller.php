<?php
/**
   * Simple pagination using CodeIgniter
   * 
   * The controller: /application/controllers/Pagination_controller.php (this file)
   * The view:       /application/views/pagination/Pagination_controller.php
   * The model:       /application/views/Pagination_model.php
   * 
   */
class Pagination_controller extends CI_Controller 
{
    public function __construct() {
        parent:: __construct();
        $this->load->helper("url");
         // $data['base']=$this->config->item('base_url');
        $this->load->model("Pagination_model"); 
         /* Load the 'pagination' library */
          /* Load the 'pagination' library */
        $this->load->library("pagination");
    }

    public function pagination_example() {
    // Set array for PAGINATION LIBRARY, and show view data according to page.
        // Set array for PAGINATION LIBRARY, and show view data according to page.
         // Initialize empty array.
        $config = array();
        // Set base_url for every links
        $config["base_url"] = base_url() . "Pagination_controller/pagination_example";
        // Set total rows in the result set you are creating pagination for.
        // $config["total_rows"] = $this->Pagination_model->record_count();

        $total_row = $this->Pagination_model->record_count();
$config["total_rows"] = $total_row;

        // Number of items you intend to show per page.
        $config["per_page"] = 1;
        // Use pagination number for anchor URL.
        $config['use_page_numbers'] = TRUE;
        $config["uri_segment"] = 3;
        $choice = $config["total_rows"] / $config["per_page"];
        //Set that how many number of pages you want to view.
        $config["num_links"] = round($choice);

          // $config['full_tag_open'] = '<div class="pagination"><ul>';
  // $config['full_tag_close'] = '</ul></div>';
        // Open tag for CURRENT link.
// $config['cur_tag_open'] = '&nbsp;<a class="current">';

// Close tag for CURRENT link.
// $config['cur_tag_close'] = '</a>';

// By clicking on performing NEXT pagination.
// $config['next_link'] = 'Next';

// By clicking on performing PREVIOUS pagination.
// $config['prev_link'] = 'Previous';

 // styling/html stuff
   /* This Application Must Be Used With BootStrap 3 *  */
$config['full_tag_open'] = '<div class="pagination"><ul>';
$config['full_tag_close'] = '</ul></div><!--pagination-->';

$config['first_link'] = '&laquo; First';
$config['first_tag_open'] = '<li class="prev page">';
$config['first_tag_close'] = '</li>';

$config['last_link'] = 'Last &raquo;';
$config['last_tag_open'] = '<li class="next page">';
$config['last_tag_close'] = '</li>';

$config['next_link'] = 'Next &rarr;';
$config['next_tag_open'] = '<li class="next page">';
$config['next_tag_close'] = '</li>';

$config['prev_link'] = '&larr; Previous';
$config['prev_tag_open'] = '<li class="prev page">';
$config['prev_tag_close'] = '</li>';

$config['cur_tag_open'] = '<li class="active"><a href="">';
$config['cur_tag_close'] = '</a></li>';

$config['num_tag_open'] = '<li class="page">';
$config['num_tag_close'] = '</li>';
// To initialize "$config" array and set to pagination library.
        $this->pagination->initialize($config);
 /* Get the page number from the URI (/index.php/pagination/index/{pageid}) */
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

        $data["results"] = $this->Pagination_model->fetch_users($config["per_page"], $page);

         // echo '<pre>'; print_r($data);die;
// Create link.
        $str_links  = $this->pagination->create_links();

        $data["links"] = explode('&nbsp;',$str_links );

       // echo '<pre>'; print_r($data);die;

        $this->load->view("pagination/Pagination_view", $data);
    }
}