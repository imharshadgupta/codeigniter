<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class My_PHPMailer {
    public function My_PHPMailer1() {
    	require_once('class.pop3.php');
require_once('class.phpmailer.php');
require_once('class.smtp.php');
        require_once('PHPMailer/PHPMailerAutoload.php');
       // return $mail = new PHPMailer;
    }
}