<?php 
class My_Controller extends CI_Controller
{

    public function __construct() {

        parent::__construct();
           

    }
     public function testing(){
        echo "code to get_the right page here";
    }
}