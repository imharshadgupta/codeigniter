<?php 
// function common_file_upload($file, $post = NULL, $path) {
//       if(!empty($file)) {

//         // echo '<pre>';print_r($file);die;
//         $tmpFile = $file['Filedata']['tmp_name'];
//         $file_name_arr = explode('.',$file['Filedata']['name']);
//         $extention = end($file_name_arr);
//         $file_name = $file_name_arr[0].strtotime('now');
//         $new_name = $file_name.'.'.$extention;
//         $new_name= !empty($new_name) ? str_replace(' ', '_', $new_name) : NULL;
//         // echo base_url().$path;die;

//         $abs_pathfile = base_url().$path.'/'.$new_name;  
//         $rel_pathfile = realpath(dirname(dirname(dirname(__FILE__)))).$path.'/'.$new_name;
//         if(move_uploaded_file($tmpFile,$rel_pathfile)){
//            return $abs_pathfile; 
//         } else {
//           return '0';
//         }
//       }
//     }


      function multiple_upload($files, $post = NULL, $path)
  {
   $obj =& get_instance(); 
      $config['upload_path'] = $path;
            $config['allowed_types'] = 'gif|jpg|png';
            // $config['max_size']    = '550';

        //initialize upload class
        $obj->load->library('upload', $config);
            
        
        $upload_error = array();
        
        for($i=0; $i<count($files['userFiles']['name']); $i++)
        {
            $_FILES['userfile']['name']= $files['userFiles']['name'][$i];
            $_FILES['userfile']['type']= $files['userFiles']['type'][$i];
            $_FILES['userfile']['tmp_name']= $files['userFiles']['tmp_name'][$i];
            $_FILES['userfile']['error']= $files['userFiles']['error'][$i];
            $_FILES['userfile']['size']= $files['userFiles']['size'][$i];

              $fileName = 'harsh_'.$_FILES['userfile']['name'];
            $images[] = $fileName;
            $config['file_name'] = $fileName; //new file name

              
             $obj->upload->initialize($config); // load new config setting 
            if (!$obj->upload->do_upload())
            {
                // fail
                $upload_error = array('error' => $obj->upload->display_errors());
                print_r($upload_error);
               
            }

             if ($upload_error == NULL)
        {
          $data['uploads'][$i] = $obj->upload->data();
          
            $data['success_msg'] = '<div class="alert alert-success text-center">Finished uploading...</div>';
            // $obj->load->view('multiple_upload_view', $data);
        }

        }
      // echo '<pre>';print_r( $data);
     // echo '<pre>'; print_r( $images);die;
    $stringnames= implode(',', $images);
 return $stringnames;
}

//  function is_login(){ 
//  $obj =& get_instance(); 
//  $obj->load->library('session');
// $b= $obj->session->userdata('isUserLoggedIn');
//   // print_r($obj->session->userdata('isUserLoggedIn'));die;       
//       if(!isset($b)){
//           return true;
//       }else{
//          redirect( base_url().'users/login', 'refresh');
//       }
//   }
    

?>